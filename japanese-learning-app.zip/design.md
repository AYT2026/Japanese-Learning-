# Japanese Learning App - Design Plan

## Overview
A mobile app for learning Japanese through educational videos and reading materials. The app provides a structured learning experience with video lessons, vocabulary, grammar explanations, and practice content.

## Screen List

1. **Home Screen** - Main dashboard with learning categories and quick access
2. **Video Lessons Screen** - Browse and watch video lessons by category
3. **Video Player Screen** - Full-screen video player with playback controls
4. **Reading Materials Screen** - Browse articles, vocabulary lists, and grammar guides
5. **Article Detail Screen** - Full article content with text and examples
6. **Search Screen** - Search for lessons, articles, and vocabulary
7. **Bookmarks Screen** - Saved videos and articles for later review
8. **Settings Screen** - App preferences and user settings

## Primary Content and Functionality

### Home Screen
- **Content**: Category cards (Videos, Reading, Vocabulary, Grammar)
- **Functionality**: 
  - Tap category to navigate to specific section
  - Display recently viewed content
  - Quick links to bookmarks and search

### Video Lessons Screen
- **Content**: Grid/list of video thumbnails with titles and duration
- **Functionality**:
  - Filter by level (Beginner, Intermediate, Advanced)
  - Sort by newest, most popular, or alphabetical
  - Tap video to play
  - Add to bookmarks

### Video Player Screen
- **Content**: Full-screen video player with controls
- **Functionality**:
  - Play/pause controls
  - Progress bar with seek
  - Volume control
  - Fullscreen toggle
  - Playback speed adjustment (0.75x, 1x, 1.25x, 1.5x)
  - Bookmark button
  - Next/previous video navigation

### Reading Materials Screen
- **Content**: List of articles, vocabulary lists, and grammar guides
- **Functionality**:
  - Filter by type (Articles, Vocabulary, Grammar)
  - Filter by level
  - Search functionality
  - Tap to open article detail

### Article Detail Screen
- **Content**: Full article text with examples and images
- **Functionality**:
  - Readable text layout with proper spacing
  - Highlight and save vocabulary words
  - Bookmark article
  - Share article
  - Font size adjustment

### Search Screen
- **Content**: Search input with results
- **Functionality**:
  - Search across all content types
  - Filter results by type
  - Recent searches
  - Suggested keywords

### Bookmarks Screen
- **Content**: Saved videos and articles
- **Functionality**:
  - View all bookmarks
  - Filter by type (videos/articles)
  - Remove bookmark
  - Quick access to content

### Settings Screen
- **Content**: App preferences
- **Functionality**:
  - Theme selection (Light/Dark mode)
  - Language preference
  - Notification settings
  - About app
  - Version info

## Key User Flows

### Learning Flow
1. User opens app → Home screen
2. User taps "Videos" category → Video Lessons screen
3. User browses videos by level
4. User taps video → Video Player screen
5. User watches video with controls
6. User bookmarks video for later
7. User navigates to next video or returns to list

### Reading Flow
1. User opens app → Home screen
2. User taps "Reading" category → Reading Materials screen
3. User browses articles by level
4. User taps article → Article Detail screen
5. User reads article with proper formatting
6. User can bookmark or share article
7. User returns to reading list or searches for related content

### Bookmark Review Flow
1. User taps "Bookmarks" in tab bar → Bookmarks screen
2. User views saved videos and articles
3. User taps saved item to resume learning
4. User can remove bookmark

## Color Choices

### Primary Colors
- **Primary Brand**: `#0a7ea4` (Teal Blue) - Used for buttons, links, and accents
- **Background**: `#ffffff` (Light) / `#151718` (Dark)
- **Surface**: `#f5f5f5` (Light) / `#1e2022` (Dark)
- **Text Primary**: `#11181C` (Light) / `#ECEDEE` (Dark)
- **Text Secondary**: `#687076` (Light) / `#9BA1A6` (Dark)

### Accent Colors
- **Success**: `#22C55E` (Green) - For completed lessons
- **Warning**: `#F59E0B` (Amber) - For important notes
- **Error**: `#EF4444` (Red) - For errors

## Layout Principles

- **Mobile Portrait (9:16)**: All screens designed for portrait orientation
- **One-Handed Usage**: Important controls positioned within thumb reach
- **Safe Area**: Proper padding for notch and home indicator
- **Tab Bar Navigation**: Persistent tab bar for main sections (Home, Videos, Reading, Bookmarks, Settings)
- **Consistent Spacing**: 4px, 8px, 12px, 16px, 24px grid
- **Typography**: Clear hierarchy with bold titles and readable body text

## iOS Human Interface Guidelines Alignment

- **Navigation**: Tab bar at bottom for primary navigation
- **Buttons**: Rounded buttons with proper touch targets (44pt minimum)
- **Spacing**: Consistent padding and margins throughout
- **Colors**: Use semantic colors that adapt to light/dark mode
- **Feedback**: Haptic feedback on interactions, loading states
- **Accessibility**: Proper contrast ratios and text sizing
