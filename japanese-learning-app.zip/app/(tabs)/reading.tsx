import { ScrollView, Text, View, Pressable, FlatList } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";

interface Article {
  id: string;
  title: string;
  category: "Article" | "Vocabulary" | "Grammar";
  level: "Beginner" | "Intermediate" | "Advanced";
  readTime: string;
  description: string;
}

const articles: Article[] = [
  {
    id: "1",
    title: "Japanese Greetings",
    category: "Article",
    level: "Beginner",
    readTime: "5 min",
    description: "Learn common Japanese greetings",
  },
  {
    id: "2",
    title: "Common Vocabulary",
    category: "Vocabulary",
    level: "Beginner",
    readTime: "8 min",
    description: "Essential Japanese vocabulary",
  },
  {
    id: "3",
    title: "Basic Grammar Rules",
    category: "Grammar",
    level: "Beginner",
    readTime: "10 min",
    description: "Fundamental Japanese grammar",
  },
  {
    id: "4",
    title: "Particles Explained",
    category: "Grammar",
    level: "Intermediate",
    readTime: "12 min",
    description: "Understanding Japanese particles",
  },
];

const ArticleCard = ({ article, onPress }: { article: Article; onPress: () => void }) => (
  <Pressable
    onPress={onPress}
    style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
  >
    <View className="bg-surface rounded-xl p-4 mb-4 border border-border">
      <View className="flex-row justify-between items-start mb-2">
        <Text className="text-lg font-bold text-foreground flex-1 mr-2">{article.title}</Text>
        <Text className="text-xs bg-primary px-2 py-1 rounded text-background font-semibold">
          {article.category}
        </Text>
      </View>
      <Text className="text-sm text-muted mb-3">{article.description}</Text>
      <View className="flex-row justify-between">
        <Text className="text-xs text-muted">Level: {article.level}</Text>
        <Text className="text-xs text-muted">Read: {article.readTime}</Text>
      </View>
    </View>
  </Pressable>
);

export default function ReadingScreen() {
  const router = useRouter();

  const handleArticlePress = (articleId: string) => {
    router.push({
      pathname: "/(tabs)/article-detail",
      params: { id: articleId },
    } as any);
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          <Text className="text-3xl font-bold text-foreground mb-2">Reading Materials</Text>
          <Text className="text-base text-muted mb-6">Articles, vocabulary, and grammar</Text>

          <FlatList
            data={articles}
            renderItem={({ item }) => (
              <ArticleCard
                article={item}
                onPress={() => handleArticlePress(item.id)}
              />
            )}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
