import { View, Text, Pressable, ScrollView } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";

export default function VideoPlayerScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();

  const handleGoBack = () => {
    router.back();
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          <Pressable onPress={handleGoBack} className="mb-4">
            <Text className="text-primary font-semibold">Back</Text>
          </Pressable>

          <View className="bg-muted rounded-xl h-64 items-center justify-center mb-6">
            <Text className="text-6xl mb-4">Play Video</Text>
            <Text className="text-lg text-foreground">Video ID: {id}</Text>
          </View>

          <Text className="text-2xl font-bold text-foreground mb-4">Video Title</Text>
          <Text className="text-base text-muted mb-6">
            This is a video player screen. Video playback controls would go here.
          </Text>

          <View className="flex-row gap-4 mb-6">
            <Pressable className="flex-1 bg-primary rounded-lg py-3 items-center">
              <Text className="text-background font-semibold">Play</Text>
            </Pressable>
            <Pressable className="flex-1 bg-surface border border-border rounded-lg py-3 items-center">
              <Text className="text-foreground font-semibold">Bookmark</Text>
            </Pressable>
          </View>

          <View className="bg-surface rounded-lg p-4">
            <Text className="text-lg font-bold text-foreground mb-2">Description</Text>
            <Text className="text-sm text-muted">
              Learn Japanese through this comprehensive video lesson.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
