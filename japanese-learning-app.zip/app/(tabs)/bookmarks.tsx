import { ScrollView, Text, View, Pressable, FlatList } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";

interface Bookmark {
  id: string;
  title: string;
  type: "Video" | "Article";
  dateAdded: string;
}

const bookmarks: Bookmark[] = [
  {
    id: "1",
    title: "Japanese Basics",
    type: "Video",
    dateAdded: "Today",
  },
  {
    id: "2",
    title: "Common Vocabulary",
    type: "Article",
    dateAdded: "Yesterday",
  },
];

const BookmarkCard = ({ bookmark, onPress }: { bookmark: Bookmark; onPress: () => void }) => (
  <Pressable
    onPress={onPress}
    style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
  >
    <View className="bg-surface rounded-xl p-4 mb-4 border border-border flex-row items-center justify-between">
      <View className="flex-1">
        <Text className="text-lg font-bold text-foreground mb-1">{bookmark.title}</Text>
        <Text className="text-sm text-muted">Added {bookmark.dateAdded}</Text>
      </View>
      <Text className="text-xs bg-primary px-2 py-1 rounded text-background font-semibold">
        {bookmark.type}
      </Text>
    </View>
  </Pressable>
);

export default function BookmarksScreen() {
  const router = useRouter();

  const handleBookmarkPress = (bookmarkId: string) => {
    router.push({
      pathname: "/(tabs)/article-detail",
      params: { id: bookmarkId },
    } as any);
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          <Text className="text-3xl font-bold text-foreground mb-2">Bookmarks</Text>
          <Text className="text-base text-muted mb-6">Your saved videos and articles</Text>

          {bookmarks.length > 0 ? (
            <FlatList
              data={bookmarks}
              renderItem={({ item }) => (
                <BookmarkCard
                  bookmark={item}
                  onPress={() => handleBookmarkPress(item.id)}
                />
              )}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
            />
          ) : (
            <View className="flex-1 items-center justify-center">
              <Text className="text-lg text-muted">No bookmarks yet</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
