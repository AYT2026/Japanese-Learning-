import { ScrollView, Text, View, Pressable, Switch } from "react-native";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { useColors } from "@/hooks/use-colors";

import { ScreenContainer } from "@/components/screen-container";

export default function SettingsScreen() {
  const colorScheme = useColorScheme();
  const colors = useColors();

  const handleThemeToggle = () => {
    // Theme toggle would be implemented here
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          <Text className="text-3xl font-bold text-foreground mb-6">Settings</Text>

          {/* Theme Section */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-4">Appearance</Text>
            <View className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between">
              <View>
                <Text className="text-base font-semibold text-foreground">Dark Mode</Text>
                <Text className="text-sm text-muted">Currently: {colorScheme === "dark" ? "On" : "Off"}</Text>
              </View>
              <Switch
                value={colorScheme === "dark"}
                onValueChange={handleThemeToggle}
              />
            </View>
          </View>

          {/* Language Section */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-4">Language</Text>
            <Pressable className="bg-surface rounded-xl p-4 border border-border">
              <Text className="text-base font-semibold text-foreground mb-1">App Language</Text>
              <Text className="text-sm text-muted">English</Text>
            </Pressable>
          </View>

          {/* Notifications Section */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-4">Notifications</Text>
            <View className="bg-surface rounded-xl p-4 border border-border flex-row items-center justify-between">
              <View>
                <Text className="text-base font-semibold text-foreground">Push Notifications</Text>
                <Text className="text-sm text-muted">Get learning reminders</Text>
              </View>
              <Switch
                value={true}
                onValueChange={() => {}}
              />
            </View>
          </View>

          {/* About Section */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-foreground mb-4">About</Text>
            <View className="bg-surface rounded-xl p-4 border border-border">
              <View className="mb-3 pb-3 border-b border-border">
                <Text className="text-sm text-muted">App Version</Text>
                <Text className="text-base font-semibold text-foreground">1.0.0</Text>
              </View>
              <View>
                <Text className="text-sm text-muted">Build</Text>
                <Text className="text-base font-semibold text-foreground">2026.05.08</Text>
              </View>
            </View>
          </View>

          {/* Help Section */}
          <Pressable className="bg-primary rounded-lg py-3 items-center">
            <Text className="text-background font-semibold">Contact Support</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
