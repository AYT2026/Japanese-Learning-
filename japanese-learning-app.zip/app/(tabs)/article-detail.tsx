import { View, Text, Pressable, ScrollView } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";

export default function ArticleDetailScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();

  const handleGoBack = () => {
    router.back();
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          <Pressable onPress={handleGoBack} className="mb-4">
            <Text className="text-primary font-semibold">Back</Text>
          </Pressable>

          <Text className="text-3xl font-bold text-foreground mb-4">Article Title</Text>
          <View className="flex-row justify-between mb-6 pb-4 border-b border-border">
            <Text className="text-sm text-muted">Beginner Level</Text>
            <Text className="text-sm text-muted">5 min read</Text>
          </View>

          <Text className="text-base text-foreground leading-relaxed mb-6">
            This is the article content. Here you can read detailed information about Japanese language learning.
            The text is formatted for easy reading with proper spacing and line height.
          </Text>

          <Text className="text-lg font-bold text-foreground mb-3">Key Points</Text>
          <View className="bg-surface rounded-lg p-4 mb-6">
            <Text className="text-sm text-foreground mb-2">• Point 1: Important concept</Text>
            <Text className="text-sm text-foreground mb-2">• Point 2: Another concept</Text>
            <Text className="text-sm text-foreground">• Point 3: Final concept</Text>
          </View>

          <View className="flex-row gap-4">
            <Pressable className="flex-1 bg-primary rounded-lg py-3 items-center">
              <Text className="text-background font-semibold">Bookmark</Text>
            </Pressable>
            <Pressable className="flex-1 bg-surface border border-border rounded-lg py-3 items-center">
              <Text className="text-foreground font-semibold">Share</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
