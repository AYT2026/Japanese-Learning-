import { ScrollView, Text, View, Pressable, FlatList } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";

interface Video {
  id: string;
  title: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  duration: string;
  description: string;
}

const videos: Video[] = [
  {
    id: "1",
    title: "Japanese Basics",
    level: "Beginner",
    duration: "12:34",
    description: "Learn basic Japanese",
  },
  {
    id: "2",
    title: "Hiragana",
    level: "Beginner",
    duration: "15:20",
    description: "Learn Hiragana characters",
  },
  {
    id: "3",
    title: "Katakana",
    level: "Beginner",
    duration: "14:50",
    description: "Learn Katakana characters",
  },
  {
    id: "4",
    title: "Kanji",
    level: "Intermediate",
    duration: "18:45",
    description: "Learn Kanji characters",
  },
];

const VideoCard = ({ video, onPress }: { video: Video; onPress: () => void }) => (
  <Pressable
    onPress={onPress}
    style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
  >
    <View className="bg-surface rounded-xl overflow-hidden mb-4 border border-border">
      <View className="bg-muted h-32 items-center justify-center">
        <Text className="text-5xl">Play</Text>
      </View>
      <View className="p-4">
        <View className="flex-row justify-between items-start mb-2">
          <Text className="text-lg font-bold text-foreground flex-1 mr-2">{video.title}</Text>
          <Text className="text-xs bg-primary px-2 py-1 rounded text-background font-semibold">
            {video.level}
          </Text>
        </View>
        <Text className="text-sm text-muted mb-2">{video.description}</Text>
        <Text className="text-xs text-muted">Duration: {video.duration}</Text>
      </View>
    </View>
  </Pressable>
);

export default function VideosScreen() {
  const router = useRouter();

  const handleVideoPress = (videoId: string) => {
    router.push({
      pathname: "/(tabs)/video-player",
      params: { id: videoId },
    } as any);
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          <Text className="text-3xl font-bold text-foreground mb-2">Video Lessons</Text>
          <Text className="text-base text-muted mb-6">Watch educational videos</Text>

          <FlatList
            data={videos}
            renderItem={({ item }) => (
              <VideoCard
                video={item}
                onPress={() => handleVideoPress(item.id)}
              />
            )}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
