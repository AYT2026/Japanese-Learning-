import { ScrollView, Text, View, Pressable, FlatList } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface Category {
  id: string;
  title: string;
  description: string;
  icon: string;
  route: string;
}

const categories: Category[] = [
  {
    id: "videos",
    title: "ဗီဒီယို",
    description: "ပညာပေး ဗီဒီယို သင်ခန်းစာများ",
    icon: "▶️",
    route: "/(tabs)/videos",
  },
  {
    id: "reading",
    title: "စာဖတ်ခြင်း",
    description: "ဆောင်းပါးများ နှင့် စာအုပ်များ",
    icon: "📖",
    route: "/(tabs)/reading",
  },
  {
    id: "vocabulary",
    title: "စကားလုံးများ",
    description: "ဂျပန်စကားလုံး စုစည်းမှု",
    icon: "📚",
    route: "/(tabs)/vocabulary",
  },
  {
    id: "grammar",
    title: "သ法်စည်းမျဉ်း",
    description: "ဂျပန်စာ သဒ္ဒါ သင်ခန်းစာများ",
    icon: "✏️",
    route: "/(tabs)/grammar",
  },
];

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();

  const handleCategoryPress = (route: any) => {
    router.push(route);
  };

  const renderCategoryCard = ({ item }: { item: Category }) => (
    <Pressable
      onPress={() => handleCategoryPress(item.route as any)}
      style={({ pressed }) => [{
        opacity: pressed ? 0.7 : 1,
      }]}
    >
      <View className="bg-surface rounded-2xl p-6 mb-4 border border-border">
        <Text className="text-4xl mb-3">{item.icon}</Text>
        <Text className="text-xl font-bold text-foreground mb-2">{item.title}</Text>
        <Text className="text-sm text-muted leading-relaxed">{item.description}</Text>
      </View>
    </Pressable>
  );

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1">
          {/* Header */}
          <View className="mb-8">
            <Text className="text-4xl font-bold text-foreground mb-2">ဂျပန်စာ</Text>
            <Text className="text-base text-muted">လေ့လာရန် အဆင်သင့်ရှိပါသလား?</Text>
          </View>

          {/* Categories */}
          <FlatList
            data={categories}
            renderItem={renderCategoryCard}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
